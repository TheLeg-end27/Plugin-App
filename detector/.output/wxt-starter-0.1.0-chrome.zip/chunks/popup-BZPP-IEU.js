(function(){let e=document.createElement(`link`).relList;if(e&&e.supports&&e.supports(`modulepreload`))return;for(let e of document.querySelectorAll(`link[rel="modulepreload"]`))n(e);new MutationObserver(e=>{for(let t of e)if(t.type===`childList`)for(let e of t.addedNodes)e.tagName===`LINK`&&e.rel===`modulepreload`&&n(e)}).observe(document,{childList:!0,subtree:!0});function t(e){let t={};return e.integrity&&(t.integrity=e.integrity),e.referrerPolicy&&(t.referrerPolicy=e.referrerPolicy),e.crossOrigin===`use-credentials`?t.credentials=`include`:e.crossOrigin===`anonymous`?t.credentials=`omit`:t.credentials=`same-origin`,t}function n(e){if(e.ep)return;e.ep=!0;let n=t(e);fetch(e.href,n)}})();var e={high:{icon:`🛑`,label:`Riesgo Alto`,color:`#C0392B`},moderate:{icon:`⚠️`,label:`Riesgo Moderado`,color:`#F39C12`},low:{icon:`🛡️`,label:`Sin riesgo`,color:`#27AE60`}};function t(e){let t=e.ageDays;return e.error&&!t?`No se pudo obtener la fecha de registro de este dominio.`:t===null?`Datos de registro no disponibles.`:t<2?`Este dominio fue registrado hace menos de 48 horas. Los sitios de phishing suelen desaparecer en horas.`:t<7?`Este dominio tiene ${t} días de vida. Verifica que reconoces este sitio antes de introducir cualquier dato.`:t<30?`Este dominio fue registrado hace ${t} días. Procede con precaución si te solicita credenciales.`:`Dominio con ${t} días de antigüedad. No se han detectado indicadores de riesgo relevantes.`}function n(e){return e>=61?`#C0392B`:e>=30?`#F39C12`:`#27AE60`}async function r(){let r=document.getElementById(`app`),[i]=await chrome.tabs.query({active:!0,currentWindow:!0});if(!i?.url){r.innerHTML=`<div class="state-msg">No hay página activa.</div>`;return}let a;try{a=new URL(i.url).hostname.replace(/^www\./,``)}catch{r.innerHTML=`<div class="state-msg">URL no analizable.</div>`;return}let o=`cache:`+a,s=(await chrome.storage.local.get(o))[o];if(!s){r.innerHTML=`<div class="state-msg">Analizando <strong>${a}</strong>…<br>Recarga la página si tarda más de 5 s.</div>`;return}let c=e[s.nivel]??e.low,l=c.color;r.style.setProperty(`--level-color`,l);let u=s.ageDays===null?`N/D`:s.ageDays<1?`< 1 día`:`${s.ageDays} días`;r.innerHTML=`
    <div class="header" style="background: ${c.color}18;">
      <span class="header-icon">${c.icon}</span>
      <div class="header-info">
        <div class="header-level">${c.label}</div>
        <div class="header-domain">${a}</div>
      </div>
      <div>
        <div class="header-score">${s.scoreFinal}</div>
        <div class="header-score-label">/ 100</div>
      </div>
    </div>

    <div class="explanation">${t(s)}</div>

    <div class="indicators">
      <div class="indicator">
        <span class="indicator-name">antigüedad</span>
        <span class="indicator-value" style="color:${n(s.scoreFinal)}">${u}</span>
      </div>
      <div class="indicator">
        <span class="indicator-name">entropía</span>
        <span class="indicator-value" style="color:${n(s.entropia>3?60:0)}">${s.entropia} bits</span>
      </div>
      <div class="indicator">
        <span class="indicator-name">VirusTotal</span>
        <span class="indicator-value" style="color:rgba(255,255,255,0.4)">${s.vtActivado?s.scoreVT+` / 100`:`No consultado`}</span>
      </div>
      <div class="indicator">
        <span class="indicator-name">score final</span>
        <span class="indicator-value" style="color:${l}">${s.scoreFinal} / 100</span>
      </div>
    </div>

    <div class="footer">
      <a class="footer-link" href="https://www.incibe.es/ciudadania/tematicas/phishing" target="_blank">¿Qué es el phishing?</a>
      <button class="clear-btn" id="clear-btn">Limpiar caché</button>
    </div>
    <div class="source">RDAP · ${s.fuenteRdap??`desconocido`}</div>
  `,document.getElementById(`clear-btn`).addEventListener(`click`,async()=>{let e=await chrome.storage.local.get(null),t=Object.keys(e).filter(e=>e.startsWith(`cache:`));await chrome.storage.local.remove(t),r.innerHTML=`<div class="state-msg">Caché eliminada.</div>`})}r();