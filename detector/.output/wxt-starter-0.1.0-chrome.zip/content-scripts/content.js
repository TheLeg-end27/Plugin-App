var content=(function(){function e(e){return e}var t=e({matches:[`http://*/*`,`https://*/*`],main(){chrome.runtime.onMessage.addListener(e=>{e.type===`SHOW_BANNER`&&n(e.data)})}});function n(e){if(document.getElementById(`pd-banner-host`))return;let t=e.nivel===`high`,n=t?`#C0392B`:`#E67E22`,r=t?`🛑`:`⚠️`,i=e.ageDays===null?`antigüedad desconocida`:e.ageDays<1?`menos de 24 horas de antigüedad`:`${e.ageDays} día${e.ageDays===1?``:`s`} de antigüedad`,a=t?`Este dominio fue registrado hace ${i}. Los sitios de phishing suelen desaparecer en horas.`:`Este dominio tiene ${i}. Verifica que reconoces este sitio antes de introducir cualquier dato.`,o=document.createElement(`div`);o.id=`pd-banner-host`,o.style.cssText=`
    all: initial;
    position: fixed;
    top: 0; left: 0; right: 0;
    width: 100%;
    z-index: 2147483647;
    display: block;
  `;let s=o.attachShadow({mode:`closed`});s.innerHTML=`
    <style>
      :host { all: initial; }
      #banner {
        background: ${n};
        color: white;
        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
        font-size: 13px;
        padding: 10px 16px;
        display: flex;
        align-items: center;
        gap: 10px;
        box-shadow: 0 2px 12px rgba(0,0,0,0.4);
        width: 100%;
        box-sizing: border-box;
      }
      .icon { font-size: 16px; flex-shrink: 0; }
      .text { flex: 1; min-width: 0; }
      .main { font-weight: 600; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
      .sub  { font-size: 11px; opacity: 0.9; margin-top: 2px; }
      button {
        background: rgba(255,255,255,0.2);
        border: 1px solid rgba(255,255,255,0.4);
        color: white;
        padding: 5px 12px;
        border-radius: 5px;
        font-size: 12px;
        font-weight: 600;
        cursor: pointer;
        font-family: inherit;
        white-space: nowrap;
        flex-shrink: 0;
      }
      button:disabled {
        opacity: 0.5;
        cursor: default;
      }
      .fp-btn {
        background: transparent;
        border: none;
        color: rgba(255,255,255,0.6);
        font-size: 11px;
        cursor: pointer;
        padding: 4px 8px;
        flex-shrink: 0;
      }
    </style>
    <div id="banner">
      <span class="icon">${r}</span>
      <div class="text">
        <div class="main">Dominio sospechoso · ${e.domain}</div>
        <div class="sub">${a}</div>
      </div>
      <button id="continue-btn" ${t?`disabled`:``}>
        ${t?`Continuar (5s)`:`Entendido`}
      </button>
      <button class="fp-btn" id="fp-btn">No mostrar más</button>
    </div>
  `;let c=s.getElementById(`continue-btn`),l=s.getElementById(`fp-btn`),u=()=>{document.body.style.marginTop=``,o.remove()};if(t){let e=5,t=setInterval(()=>{e--,e>0?c.textContent=`Continuar (${e}s)`:(clearInterval(t),c.textContent=`Continuar de todas formas`,c.disabled=!1)},1e3)}c.addEventListener(`click`,u),l.addEventListener(`click`,()=>{chrome.runtime.sendMessage({type:`ADD_WHITELIST`,domain:e.domain}),u()}),document.documentElement.insertBefore(o,document.documentElement.firstChild),requestAnimationFrame(()=>{document.body.style.marginTop=`${o.offsetHeight+4}px`})}var r={debug:(...e)=>([...e],void 0),log:(...e)=>([...e],void 0),warn:(...e)=>([...e],void 0),error:(...e)=>([...e],void 0)},i=globalThis.browser?.runtime?.id?globalThis.browser:globalThis.chrome,a=class e extends Event{static EVENT_NAME=o(`wxt:locationchange`);constructor(t,n){super(e.EVENT_NAME,{}),this.newUrl=t,this.oldUrl=n}};function o(e){return`${i?.runtime?.id}:content:${e}`}var s=typeof globalThis.navigation?.addEventListener==`function`;function c(e){let t,n=!1;return{run(){n||(n=!0,t=new URL(location.href),s?globalThis.navigation.addEventListener(`navigate`,e=>{let n=new URL(e.destination.url);n.href!==t.href&&(window.dispatchEvent(new a(n,t)),t=n)},{signal:e.signal}):e.setInterval(()=>{let e=new URL(location.href);e.href!==t.href&&(window.dispatchEvent(new a(e,t)),t=e)},1e3))}}}var l=class e{static SCRIPT_STARTED_MESSAGE_TYPE=o(`wxt:content-script-started`);id;abortController;locationWatcher=c(this);constructor(e,t){this.contentScriptName=e,this.options=t,this.id=Math.random().toString(36).slice(2),this.abortController=new AbortController,this.stopOldScripts(),this.listenForNewerScripts()}get signal(){return this.abortController.signal}abort(e){return this.abortController.abort(e)}get isInvalid(){return i.runtime?.id??this.notifyInvalidated(),this.signal.aborted}get isValid(){return!this.isInvalid}onInvalidated(e){return this.signal.addEventListener(`abort`,e),()=>this.signal.removeEventListener(`abort`,e)}block(){return new Promise(()=>{})}setInterval(e,t){let n=setInterval(()=>{this.isValid&&e()},t);return this.onInvalidated(()=>clearInterval(n)),n}setTimeout(e,t){let n=setTimeout(()=>{this.isValid&&e()},t);return this.onInvalidated(()=>clearTimeout(n)),n}requestAnimationFrame(e){let t=requestAnimationFrame((...t)=>{this.isValid&&e(...t)});return this.onInvalidated(()=>cancelAnimationFrame(t)),t}requestIdleCallback(e,t){let n=requestIdleCallback((...t)=>{this.signal.aborted||e(...t)},t);return this.onInvalidated(()=>cancelIdleCallback(n)),n}addEventListener(e,t,n,r){t===`wxt:locationchange`&&this.isValid&&this.locationWatcher.run(),e.addEventListener?.(t.startsWith(`wxt:`)?o(t):t,n,{...r,signal:this.signal})}notifyInvalidated(){this.abort(`Content script context invalidated`),r.debug(`Content script "${this.contentScriptName}" context invalidated`)}stopOldScripts(){document.dispatchEvent(new CustomEvent(e.SCRIPT_STARTED_MESSAGE_TYPE,{detail:{contentScriptName:this.contentScriptName,messageId:this.id}})),window.postMessage({type:e.SCRIPT_STARTED_MESSAGE_TYPE,contentScriptName:this.contentScriptName,messageId:this.id},`*`)}verifyScriptStartedEvent(e){let t=e.detail?.contentScriptName===this.contentScriptName,n=e.detail?.messageId===this.id;return t&&!n}listenForNewerScripts(){let t=e=>{!(e instanceof CustomEvent)||!this.verifyScriptStartedEvent(e)||this.notifyInvalidated()};document.addEventListener(e.SCRIPT_STARTED_MESSAGE_TYPE,t),this.onInvalidated(()=>document.removeEventListener(e.SCRIPT_STARTED_MESSAGE_TYPE,t))}},u={debug:(...e)=>([...e],void 0),log:(...e)=>([...e],void 0),warn:(...e)=>([...e],void 0),error:(...e)=>([...e],void 0)};return(async()=>{try{let{main:e,...n}=t;return await e(new l(`content`,n))}catch(e){throw u.error(`The content script "content" crashed on startup!`,e),e}})()})();
content;